//
//  Familiar+CoreDataClass.swift
//  
//
//  Created by Emmanuel Santos on 11/5/19.
//

import Foundation
import CoreData

@objc(Familiar)
public class Familiar: NSManagedObject{
    
}

