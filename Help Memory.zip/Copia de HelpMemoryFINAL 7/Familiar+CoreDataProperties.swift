//
//  Familiar+CoreDataProperties.swift
//  
//
//  Created by Emmanuel Santos on 11/5/19.
//

import Foundation
import CoreData

extension Familiar {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Familiar> {
        return NSFetchRequest<Familiar>(entityName: "Familiar")
    }
    
    @NSManaged public var apellido: String?
    @NSManaged public var direccion: String?
    @NSManaged public var edad: Int16
    @NSManaged public var direccion: String?
    @NSManaged public var foto: Binary
    @NSManaged public var id: Int16
    @NSManaged public var nombre: String?
    @NSManaged public var relacion: String?
}
