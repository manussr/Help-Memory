//
//  RunningTimeRepository.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/14/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation

class RunningTimeRepository {
    static var calificacion = String()
    
    static let instance = RunningTimeRepository()
    
    var timeGraphCollection: [TimeGraphData]?
    
    func retrieveTimeGraphCollection (completion: @escaping ([TimeGraphData]?) -> ()) {
        
        if timeGraphCollection != nil {
            completion(timeGraphCollection)
        } else {
           print("La calificacion resulto \(RunningTimeRepository.calificacion)")
            timeGraphCollection = self.createTimeCollection()
            completion(timeGraphCollection)
        }
    }
    
    func createTimeCollection () -> [TimeGraphData] {
                   var respuesta1: Int = 1
                    var respuesta2: Int = 1
                    var respuesta3: Int = 1
                    var respuesta4: Int = 1
                    var respuestas: Int = 1
                    
                    switch RunningTimeRepository.calificacion{
                    case "mala":
                        respuesta1 += 1
                        break

                    case "regular":
                        respuesta2 += 1
                        break
                    case "buena"
        :
                        respuesta3 += 1
                        break
                    case "excelente":
                        respuesta4 += 1
                        break
                    default:
                        respuesta4 += 0
                        break
        }
                    
        respuestas = respuesta1+respuesta2+respuesta3+respuesta4
        
        let mala = TimeGraphData.init(order: 0, amount: "regular", month: "Ago", percentage: 40)
        let buena = TimeGraphData.init(order: 1, amount: "buena", month: "Sep", percentage:60 )
        let regular = TimeGraphData.init(order: 2, amount: "regular", month: "Oct", percentage:50 )
        let excelente = TimeGraphData.init(order: 3, amount: "excelente", month: "Dic", percentage:90.0 )

        
        return [mala,buena,regular,excelente]
        
        }
}
