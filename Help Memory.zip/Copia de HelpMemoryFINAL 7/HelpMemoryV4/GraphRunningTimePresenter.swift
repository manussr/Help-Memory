//
//  GraphRunningTimePresenter.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/14/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation


class GraphRunningTimePresenter {
    
    var graphRunningTimeView: GraphRunningTimeView?
    var runningTimeRepository: RunningTimeRepository?
    
    init(runningTimeRepository: RunningTimeRepository) {
        self.runningTimeRepository = runningTimeRepository
    }
    
    func attachView (view: GraphRunningTimeView) {
        graphRunningTimeView = view
    }
    
    func detachView () {
        graphRunningTimeView = nil
    }
    
    func viewDidLoad() {
    }
    
    func viewDidAppear() {
    }
    
    func viewWillAppear() {
        self.updateInterface()
    }
    
    func viewDidDisappear() {
    }
    
    func updateInterface () {
    runningTimeRepository?.retrieveTimeGraphCollection(completion: { (runningGraphDataCollection) in
            if runningGraphDataCollection != nil {
                self.graphRunningTimeView?.updateInfo(runningTimeCollection: runningGraphDataCollection!)
            }
            
        })
    }
}
