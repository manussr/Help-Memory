//
//  actualizar.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/11/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation
import CoreData
import UIKit

var getrecord = NSManagedObject()
class actualizar : UIViewController{
    
    
}
