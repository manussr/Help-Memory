//
//  EstadisticasViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit

class EstadisticasViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
