//
//  TimeGraphData.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/14/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation

struct TimeGraphData {
    var order: Int
    var amount: String
    var month: String
    var percentage: Double
    
    init (order: Int, amount: String, month: String, percentage: Double) {
        self.order = order
        self.amount = amount
        self.month = month
        self.percentage = percentage
    }
}
