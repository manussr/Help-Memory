//
//  ConsultaViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import CoreData

class ConsultaViewController: UIViewController {
    
    
    @IBOutlet var imgProfile: UIImageView!
    @IBOutlet var nombre: UITextField!
    @IBOutlet var Apellido: UITextField!
    @IBOutlet var edad: UITextField!
    @IBOutlet var relacion: UITextField!
    @IBOutlet var direccion: UITextField!

    
    var named: String = ""
    var relacioon:String = ""
    var idF: Int = 0
    
    

    
    var date: ChattModel?{
        didSet{
            named = date!.nombre!
            relacioon = date!.relacion!
            idF = date!.id!
        }
    }
    
    func getContext() -> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as!
        AppDelegate
        return appDelegate.persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.consultar(idN: idF)
    }
    
    func consultar(idN: Int){
        _ = getContext()
       let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
        do{
            let results = try getContext().fetch(fetchRequest)
            if results.count > 0{
                for result in results as! [NSManagedObject]{
                    let nombrem = result.value(forKey: "nombre")! as? String
                    let relacions = result.value(forKey: "relacion")! as? String
                    let apellido = result.value(forKey: "apellido")! as? String
                    let edads = result.value(forKey: "edad")! as! Int
                    let direccionr = result.value(forKey: "direccion")! as? String
                    let id = result.value(forKey: "id")! as? Int
                    let imageData = result.value(forKey: "foto")! as? Data
                    
                    if idN == id {
                        nombre.text = nombrem
                        Apellido.text = apellido
                        edad.text = ""+String(edads)
                        relacion.text = relacions
                        direccion.text = direccionr
                        if let image = UIImage(data:imageData!) {
                            imgProfile.image = image
                        }
                        
                    }
                }
            }
        }
        catch{
            print("Error de consulta")
        }
    }
    

   
   

    
    func eliminarQ(idN: Int)-> Bool{
        var eliminar: Bool = false
        let contex = getContext()
        let familiar = NSEntityDescription.entity(forEntityName: "Familiar", in: contex)
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
        fetchRequest.entity = familiar
        do{
            let results = try getContext().fetch(fetchRequest)
            if results.count > 0 {
                for result in results as! [NSManagedObject]{
                    let id = result.value(forKey: "id") as? Int
                    if idN == id{
                        contex.delete(result)
                        do{
                            try contex.save()
                            let alertController = UIAlertController(title: "BIEN!", message:
                                "Persona eliminada correctamente.", preferredStyle: .alert)
                            alertController.addAction(UIAlertAction(title: "CONTINUAR", style: .default))
                            self.present(alertController, animated: true, completion: nil)
                            eliminar = true
                        }
                        catch{
                            print("Error al eliminar")
                        }
                    }
                }
            }
            
        }
        catch{
            print("Error en consulta")
        }
        
        return eliminar
    }

    
    @IBAction func eliminar(_ sender: Any) {
        var band: Bool?
        band = self.eliminarQ(idN: idF)
        if band == true{
            nombre.text = String ("")
            Apellido.text = String ("")
            edad.text = String ("")
            relacion.text = String ("")
            direccion.text = String ("")
            imgProfile.image = UIImage(named: "profileIMG_1")

        }
        
    }
    
    /* let familiar = NSManagedObject(entity: entity,insertInto: managedContext)!
     familiar.setValue(nombre, forKeyPath: "nombre")
     familiar.setValue(edad, forKeyPath: "edad")
     familiar.setValue(apellido, forKeyPath: "apellido")
     familiar.setValue(relacion, forKeyPath: "relacion")
     familiar.setValue(direccion, forKeyPath: "direccion")
     familiar.setValue(foto, forKeyPath: "foto")
     
     
     NSEntityDescription.entity(forEntityName: "Familiar", in: contex)
     
     */
    @IBAction func editar(_ sender: UIButton) {
        
        let contex = getContext()
         let entity = NSEntityDescription.entity(forEntityName: "Familiar", in: contex)
        let request = NSFetchRequest<NSFetchRequestResult>()
         request.entity = entity
         let newName = UserDefaults.standard.value(forKey: "nombre") as! String
         let predicate = NSPredicate(format: "(nombre = %@)", newName)
         request.predicate = predicate
         do {
             let results =
                 try contex.fetch(request)
             let objectUpdate = results[0] as! NSManagedObject
             objectUpdate.setValue(nombre.text!, forKey: "nombre")
             objectUpdate.setValue(Apellido.text!, forKey: "Apellido")
             objectUpdate.setValue(direccion.text!, forKey: "direccion")
             objectUpdate.setValue(relacion.text!, forKey: "relacion")
             objectUpdate.setValue(edad.text!, forKey: "edad")
             //objectUpdate.setValue(<#T##value: Any?##Any?#>, forKey: <#T##String#>)
             do {
                 try contex.save()
                 //labelStatus.text = "Updated"
             }catch let error as NSError {
                 //UIAlertAction. = error.localizedFailureReason
             }
         }
         catch let error as NSError {
             //labelStatus.text = error.localizedFailureReason
         }
        
    }
    
   func update(nombre:String, edad: Int16,apellido: String,relacion:String,direccion:String,id: Int16, familiar : Familiar) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        
        do {
            familiar.setValue(nombre, forKeyPath: "nombre")
            familiar.setValue(edad, forKeyPath: "edad")
            familiar.setValue(apellido, forKeyPath: "apellido")
            familiar.setValue(relacion, forKeyPath: "relacion")
            familiar.setValue(direccion, forKeyPath: "direccion")
           // familiar.setValue(foto, forKeyPath: "foto")
            
            print("\(String(describing: familiar.value(forKey: "nombre")))")
            print("\(String(describing: familiar.value(forKey: "edad")))")
            print("\(String(describing: familiar.value(forKey: "apellido")))")
            print("\(String(describing: familiar.value(forKey: "relacion")))")
            print("\(String(describing: familiar.value(forKey: "direccion")))")
   do {
                try context.save()
                print("saved!")
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            } catch {
                
            }
            
        } catch {
            print("Error with request: \(error)")
        }
    }
}

    


