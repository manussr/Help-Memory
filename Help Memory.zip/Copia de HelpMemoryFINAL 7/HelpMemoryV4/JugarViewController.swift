//
//  JugarViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import CoreData

class JugarViewController: UIViewController {
    
    
    @IBOutlet var imgPregunta: UIImageView!
    @IBOutlet var lblPregunta: UILabel!
    
    
    
    @IBOutlet weak var res_1: UIButton!
    @IBOutlet weak var res_2: UIButton!
    @IBOutlet weak var res_3: UIButton!
    @IBOutlet weak var res_4: UIButton!
    
    var respCallers: [UIButton] = [UIButton]()
    static var estadistica = String()
    
    
    var preguntas = ["¿Cuál es el nombre de esta persona?","¿Quién es esta persona?","¿Cuantos años tiene esta persona?"
        ,"¿Dónde vive esta persona?", "¿Cuál es tu relación con esta persona?"]
    
    var respuestaCorrecta: Int?
    var tipo: String?
    
    var respuestas: Int = 0
    var preguntasR: Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.respCallers = [self.res_1, self.res_2, self.res_3, self.res_4]
        self.generaPregunta()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func getContext() -> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as!
        AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    
    
    func generaPregunta(){
        var familiaresP = [Int]()
        familiaresP=familiaresPregunta()
        var infoRespuestas = [Int]()
        while infoRespuestas.count != 4 {
            infoRespuestas.append(familiaresP.randomElement()!)
            infoRespuestas = uniqueElements(of: infoRespuestas) as! [Int]
        }
        self.respuestaCorrecta = infoRespuestas.randomElement()!
        agregaImagen(idN: respuestaCorrecta!)
        let aux = Int.random(in: 0 ..< preguntas.count)
        
        
        if(aux == 0 || aux == 1){
            self.tipo = "nombre"
        }else if(aux == 2){
            self.tipo = "edad"
        }else if(aux == 3){
            self.tipo = "direccion"
        }else if(aux == 4){
            self.tipo = "relacion"
        }
        lblPregunta.text = preguntas[aux]
        let respuestas = generarRespuestas(tipo: self.tipo!, respuestasId: infoRespuestas)
        for i in 0..<4{
            respCallers[i].setTitle(respuestas[i], for: .normal)
        }
        
    }
    
    func uniqueElements<T: Equatable>(of array: [T?]) -> [T?] {
        return array.reduce([T?]()) { (result, item) -> [T?] in
            if result.contains(where: {$0 == item}) {
                return result
            }
            return result + [item]
        }
    }
    
    func generarRespuestas(tipo: String, respuestasId: [Int]) -> [String]{
        var respuestas = [String]()
        _ = getContext()
        if tipo == "nombre"{
            
            for i in respuestasId{
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "nombre") as? String
                                respuestas.append(res!)
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            }
            
        }
        
        if tipo == "edad"{
            
            for i in respuestasId{
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "edad") as? Int
                                respuestas.append(String(res!))
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            }
            
        }
        
        if tipo == "direccion"{
            
            for i in respuestasId{
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "direccion") as? String
                                respuestas.append(res!)
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            }
            
        }
        
        if tipo == "relacion"{
            
            for i in respuestasId{
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "relacion") as? String
                                respuestas.append(res!)
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            }
            
        }
        
        return respuestas
        
    }
    
    func familiaresPregunta() -> [Int] {
        var respuestas = [Int]()
        _ = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
        do{
            let results = try getContext().fetch(fetchRequest)
            if results.count > 0{
                for result in results as! [NSManagedObject]{
                   let id = result.value(forKey: "id") as? Int
                    respuestas.append(id!)
                }
            }
        }
        catch{
            print("Error de consulta")
        }
        
       return respuestas
        
    }
    
    func agregaImagen(idN: Int)  {
        _ = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
        do{
            let results = try getContext().fetch(fetchRequest)
            if results.count > 0 {
                for result in results as! [NSManagedObject]{
                    
                    let id = result.value(forKey: "id") as? Int
                    if idN == id{
                        let imageData = result.value(forKey: "foto")! as? Data
                        if let image = UIImage(data:imageData!) {
                            imgPregunta.image = image
                        }
                    }
                }
            }
            
        }
        catch{
            print("Error en consulta")
        }
    }
    
    
    @IBAction func respuestaButton(_ sender: UIButton) {
        
        self.preguntasR += 1
        var result: String?
        if preguntasR == 5{
            switch respuestas{
            case 0:
                result = "mala"
                break
            case 1:
                result = "mala"
                break
            case 2:
                result = "regular"
                break
            case 3:
                result = "regular"
                break
            case 4:
                result = "buena"
                break
            case 5:
                result = "excelente"
                break
            default:
                result = ""
                break
               
            }
            
            let alert = UIAlertController(title: "ESTUDIO FINALIZADO", message: "Memoria: " + result!, preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction(title: "REGRESAR", style: UIAlertAction.Style.default, handler: { _ in
                guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") else {fatalError("Unable to create viewController")}
                self.navigationController?.pushViewController(vc, animated: true)
            }))
            alert.addAction(UIAlertAction(title: "SEGUIR JUGANDO",
                                          style: UIAlertAction.Style.default,
                                          handler: {(_: UIAlertAction!) in
                                            self.preguntasR = 0
                                            self.respuestas = 0
                                            self.generaPregunta()
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
        let buttonTitle = sender.title(for: .normal)!
        let bandera=generarRespuestas(tipo: self.tipo!, i: self.respuestaCorrecta!, respuesta: buttonTitle)
        if bandera == true{
            
            let alertController = UIAlertController(title: "BIEN", message:
                "Es la respuesta correcta.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "CONTINUAR",
                                                    style: UIAlertAction.Style.default,
                                                    handler: {(_: UIAlertAction!) in
                                                        self.respuestas += 1
                                                        self.generaPregunta()
            }))
            self.present(alertController, animated: true, completion: nil)
        }else{
            let alertController = UIAlertController(title: "ERROR", message:
                "Esa respuesta es incorrecta.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "CONTINUAR",
                                          style: UIAlertAction.Style.default,
                                          handler: {(_: UIAlertAction!) in
                                            self.generaPregunta()
            }))
            self.present(alertController, animated: true, completion: nil)
        }
        
        
    }
    
    func generarRespuestas(tipo: String, i: Int, respuesta: String) -> Bool{
        var bandera: Bool = false
        _ = getContext()
        if tipo == "nombre"{
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "nombre") as? String
                                if res == respuesta{
                                    bandera = true
                                }
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            
            
        }
        
        if tipo == "edad"{
            
           let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "edad") as? Int
                                if res == Int(respuesta){
                                    bandera = true
                                }
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            
            
        }
        
        if tipo == "direccion"{
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "direccion") as? String
                                if res == respuesta{
                                    bandera = true
                                }
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            
            
        }
        
        if tipo == "relacion"{
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
                do{
                    let results = try getContext().fetch(fetchRequest)
                    if results.count > 0 {
                        for result in results as! [NSManagedObject]{
                            
                            let id = result.value(forKey: "id") as? Int
                            if i == id{
                                let res = result.value(forKey: "relacion") as? String
                                if res == respuesta{
                                    bandera = true
                                }
                            }
                        }
                    }
                    
                }
                catch{
                    print("Error en consulta")
                }
            
            
        }
        
        return bandera
        
    }
    
}
