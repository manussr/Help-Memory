//
//  GraphRunningTimeView.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/14/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation

protocol GraphRunningTimeView {
    func updateInfo (runningTimeCollection: [TimeGraphData])
}
