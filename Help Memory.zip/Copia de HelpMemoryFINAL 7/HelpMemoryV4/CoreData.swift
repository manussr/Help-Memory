//
//  CoreData.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/4/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation
//1
import CoreData
class CoreDataManager {
    //2
    private let container : NSPersistentContainer!
    //3
    init() {
        container = NSPersistentContainer(name: "Familiar")
        
        setupDatabase()
    }
    
    private func setupDatabase() {
        //4
        container.loadPersistentStores { (desc, error) in
            if let error = error {
                print("Error loading store \(desc) — \(error)")
                return
            }
            print("Database ready!")
        }
}
}
