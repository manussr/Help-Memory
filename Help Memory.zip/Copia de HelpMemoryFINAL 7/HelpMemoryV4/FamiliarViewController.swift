//
//  FamiliarViewController.swift
//  HelpMemoryV4
//
//  Created by Emmanuel Santos on 11/11/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class FamiliarViewController: UIViewController {
    
    @IBOutlet var myImg: UIImageView!
    var imagePicker = UIImagePickerController()
    var id: Int?
    @IBOutlet weak var nombre: UITextField!
    @IBOutlet weak var apellido: UITextField!
    
    @IBOutlet weak var edad: UITextField!
    
    @IBOutlet weak var relacion: UITextField!
    
    @IBOutlet weak var direccion: UITextField!
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer()
        tapGesture.addTarget(self, action: #selector(FamiliarViewController.openGallery(tapGesture:)))
        myImg.isUserInteractionEnabled = true
        myImg.addGestureRecognizer(tapGesture)
           }
    @objc func openGallery(tapGesture: UITapGestureRecognizer){
        self.setypImagePicker()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func getContext() -> NSManagedObjectContext{
            let appDelegate = UIApplication.shared.delegate as!
            AppDelegate
            return appDelegate.persistentContainer.viewContext
        }
        
        @IBAction func agregar(_ sender: Any) {
            
            if nombre.text == "" || apellido.text == "" || edad.text == "" || relacion.text == "" || direccion.text == "" || myImg.image == UIImage(named: "profileIMG_1"){
                let alertController = UIAlertController(title: "UPS!", message:
                    "Has dejado algun campo vacio.", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "CONTINUAR", style: .default))
                self.present(alertController, animated: true, completion: nil)
            }else{
                id = Int.random(in: 0 ..< 9999)
                let data = (myImg?.image)!.pngData()
                let contex = getContext()
                let familiar = NSEntityDescription.insertNewObject(forEntityName: "Familiar", into: contex)
                familiar.setValue(nombre.text!, forKey: "nombre")
                familiar.setValue(apellido.text!, forKey: "apellido")
                familiar.setValue(Int(edad.text!), forKey: "edad")
                familiar.setValue(direccion.text!, forKey: "direccion")
                familiar.setValue(relacion.text!, forKey: "relacion")
                familiar.setValue(id!, forKey: "id")
                familiar.setValue(data!, forKey: "foto")
                nombre.text = String ("")
                apellido.text = String ("")
                edad.text = String ("")
                relacion.text = String ("")
                direccion.text = String ("")
                myImg.image = UIImage(named: "profileIMG_1")
                do{
                    try contex.save()
                    let alertController = UIAlertController(title: "BIEN!", message:
                        "Persona agregada correctamente.", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "CONTINUAR", style: .default))
                    self.present(alertController, animated: true, completion: nil)
                }
                catch{
                    print("Error al almacenar")
                }
            }
        }
        
    }

    extension FamiliarViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
        
        func setypImagePicker(){
            if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
                imagePicker.sourceType = .savedPhotosAlbum
                imagePicker.delegate = self
                imagePicker.isEditing = true
                
                self.present(imagePicker, animated: true, completion: nil)
                
            }
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
            myImg.image = image
            self.dismiss(animated: true, completion: nil)
        }
        
}
