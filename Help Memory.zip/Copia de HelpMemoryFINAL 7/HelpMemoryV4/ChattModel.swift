//
//  ChattModel.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import Foundation
import UIKit

class ChattModel{
    
    var nombre: String?
    var apellidos: String?
    var edad: Int?
    var relacion: String?
    var direccion: String?
    var foto: String?
    var id: Int?
    var imgData: Data?
    
    init(nombre: String, relacion: String, id: Int, imgData: Data) {
        self.nombre = nombre
        self.relacion = relacion
        self.id = id
        self.imgData = imgData
    }
    
    init(nombre: String, apellidos: String, edad: Int, relacion: String, direccion: String, foto: String, id: Int) {
        self.nombre = nombre
        self.apellidos = apellidos
        self.edad = edad
        self.relacion = relacion
        self.direccion = direccion
        self.foto = foto
        self.id = id
    }
    
}
