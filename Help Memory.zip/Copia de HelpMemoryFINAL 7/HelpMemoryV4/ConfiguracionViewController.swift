//
//  ConfiguracionViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import CoreData

class ConfiguracionViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var people: [NSManagedObject] = []
    
    func save(nombre: String, id : Int16, Apellido: String, edad: Int, relacion: String,direccion: String) {
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
     
      let managedContext = appDelegate.persistentContainer.viewContext
      
     
      let entity = NSEntityDescription.entity(forEntityName: "Familiar",
                                              in: managedContext)!
      
    
      let familia = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
      
      familia.setValue(nombre, forKeyPath: "nombre")
      familia.setValue(id, forKeyPath: "id")
        familia.setValue(Apellido, forKey: "Apellido")
        familia.setValue(direccion, forKey: "direccion")
        familia.setValue(edad, forKey: "edad")
        familia.setValue(relacion, forKey: "relacion")
      
      do {
        try managedContext.save()
        people.append(familia)
        tableView.reloadData()
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }
    
    func delete(id: String) {
      /*get reference to appdelegate file*/
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
      /*get reference of managed object context*/
      let managedContext = appDelegate.persistentContainer.viewContext
      
      /*init fetch request*/
      let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Familiar")
      
      /*pass your condition with NSPredicate. We only want to delete those records which match our condition*/
      fetchRequest.predicate = NSPredicate(format: "id == %@" ,id)
      do {
        
        /*managedContext.fetch(fetchRequest) will return array of person objects [personObjects]*/
        let item = try managedContext.fetch(fetchRequest)
        for i in item {
          
          /*call delete method(aManagedObjectInstance)*/
          /*here i is managed object instance*/
          managedContext.delete(i)
          
          /*finally save the contexts*/
          try managedContext.save()
          
          /*update your array also*/
          people.remove(at: (people.index(of: i))!)
          
        }
        
      } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
      }
      
    }
    
    
    func fetchAllPersons(){
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
      /*Before you can do anything with Core Data, you need a managed object context. */
      let managedContext = appDelegate.persistentContainer.viewContext
      
      /*As the name suggests, NSFetchRequest is the class responsible for fetching from Core Data.
       
       Initializing a fetch request with init(entityName:), fetches all objects of a particular entity. This is what you do here to fetch all Person entities.
       */
      let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Familiar")
      
      /*You hand the fetch request over to the managed object context to do the heavy lifting. fetch(_:) returns an array of managed objects meeting the criteria specified by the fetch request.*/
      do {
        people = try managedContext.fetch(fetchRequest)
      } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
      }
      
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      fetchAllPersons()
    }
    
    override func viewDidLoad() {
      super.viewDidLoad()
      // Do any additional setup after loading the view, typically from a nib.
      tableView.register(UITableViewCell.self,
                         forCellReuseIdentifier: "Cell")
    }
    
    
    func delete(familia : Familiar){
      // Assuming type has a reference to managed object context
      
      // Assuming that a specific NSManagedObject's objectID property is accessible
      // Alternatively, could supply a predicate expression that's precise enough
      // to select only a _single_ entity
      
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      let managedContext = appDelegate.persistentContainer.viewContext
      
      do {
        
        managedContext.delete(familia)
        
      } catch {
        // Do something in response to error condition
      }
      
      do {
        try managedContext.save()
      } catch {
        // Do something in response to error condition
      }
    }
      
    
    
    
    func update(nombre: String, Apellido: String, relacion: String,direccion: String,familia : Familiar) {
      
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
     
      let context = appDelegate.persistentContainer.viewContext
      
      do {
        
      
        
          familia.setValue(nombre, forKeyPath: "nombre")
         // familia.setValue(id, forKeyPath: "id")
          familia.setValue(Apellido, forKey: "Apellido")
          familia.setValue(direccion, forKey: "direccion")
          //familia.setValue(edad, forKey: "edad")
          familia.setValue(relacion, forKey: "relacion")
        
        print("\(familia.value(forKey: "nombre"))")
        //print("\(familia.value(forKey: "id"))")
        print("\(familia.value(forKey: "Apellido"))")
        print("\(familia.value(forKey: "direccion"))")
        //print("\(familia.value(forKey: "edad"))")
        print("\(familia.value(forKey: "relacion"))")
        
        
        
        
   
        do {
          try context.save()
          print("saved!")
        } catch let error as NSError  {
          print("Could not save \(error), \(error.userInfo)")
        } catch {
          
        }
        
      } catch {
        print("Error with request: \(error)")
      }
    }
    
}

extension ConfiguracionViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let familia = people[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
        cell.textLabel?.text = familia.value(forKeyPath: "nombre") as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        
        
      /*get managed object*/
      let familia = people[indexPath.row]
      
      /*initialize alert controller*/
      let alert = UIAlertController(title: "Atualizar datos",
                                    message: "Actualizar datos",
                                    preferredStyle: .alert)
      
      /*add name textfield*/
      alert.addTextField(configurationHandler: { (textFieldName) in
        
        /*set name as plaveholder in textfield*/
        textFieldName.placeholder = "nombre"
        
        /*use key value coding to get value for key "name" and set it as text of UITextField.*/
        textFieldName.text = familia.value(forKey: "nombre") as? String
        
      })
      
    /*  /*add ssn textfield*/
     alert.addTextField(configurationHandler: { (textFieldID) in
        
        /*set ssn as plaveholder in textfield*/
        textFieldID.placeholder = "id"
        
        /*use key value coding to get value for key "ssn" and set it as text of UITextField.*/
        
        textFieldID.text = familia.value(forKey: "id") as? String
      })
      
      alert.addTextField(configurationHandler: { (textFieldedad) in
          
          /*set ssn as plaveholder in textfield*/
          textFieldedad.placeholder = "edad"
          
          /*use key value coding to get value for key "ssn" and set it as text of UITextField.*/
          
          textFieldedad.text = "\(familia.value(forKey: "edad") as? Int16 ?? 0)"
      })*/
        

        alert.addTextField(configurationHandler: { (textFieldLN) in
          
          /*set name as plaveholder in textfield*/
          textFieldLN.placeholder = "Apellido"
          
          /*use key value coding to get value for key "name" and set it as text of UITextField.*/
          textFieldLN.text = familia.value(forKey: "Apellido") as? String
          
        })
        
    alert.addTextField(configurationHandler: { (textFieldDireccion) in
      
      /*set name as plaveholder in textfield*/
      textFieldDireccion.placeholder = "direccion"
      
      /*use key value coding to get value for key "name" and set it as text of UITextField.*/
      textFieldDireccion.text = familia.value(forKey: "direccion") as? String
      
    })
    
        
    alert.addTextField(configurationHandler: { (textFieldRelacion) in
      
      /*set name as plaveholder in textfield*/
      textFieldRelacion.placeholder = "relacion"
      
      /*use key value coding to get value for key "name" and set it as text of UITextField.*/
      textFieldRelacion.text = familia.value(forKey: "relacion") as? String
      
    })
        
        
        
        
      
      /*configure update event*/
      let updateAction = UIAlertAction(title: "Update", style: .default) { [unowned self] action in
        
        guard let textField = alert.textFields?[0],
          let nameToSave = textField.text else {
            return
        }
        
        /*guard let textFieldID = alert.textFields?[1],
          let IDToSave = textFieldID.text else {
            return
        }*/
        guard let textFieldLN = alert.textFields?[1],
        let ApellidoToSave = textFieldLN.text else {
        return
        }
        guard let textFieldRelacion = alert.textFields?[2],
          let RelacionToSave = textFieldRelacion.text else {
            return
        }
       /* guard let textFieldEdad = alert.textFields?[4],
          let edadToSave = textFieldEdad.text else {
            return
        }*/
        guard let textFieldDireccion = alert.textFields?[3],
          let DireccionToSave = textFieldDireccion.text else {
            return
        }

        
        /*imp part, responsible for update, pass nameToSave and SSn to update: method.*/
        self.update(nombre: nameToSave, Apellido: ApellidoToSave, relacion: RelacionToSave, direccion: DireccionToSave, familia:familia as! Familiar)
        

        
        /*finally reload table view*/
        self.tableView.reloadData()
        
      }
      
      /*configure delete event*/
      let deleteAction = UIAlertAction(title: "Delete", style: .default) { [unowned self] action in
        
        /*look at implementation of delete method */
        
        self.delete(familia : familia as! Familiar)
        
        /*remove person object from array also, so that datasource have correct data*/
        self.people.remove(at: (self.people.index(of: familia))!)
        
        /*Finally reload tableview*/
        self.tableView.reloadData()
        
      }
      
      /*configure cancel action*/
      let cancelAction = UIAlertAction(title: "Cancel",
                                       style: .default)
      
      /*add all the actions*/
      alert.addAction(updateAction)
      alert.addAction(cancelAction)
      alert.addAction(deleteAction)
      
      /*finally present*/
      present(alert, animated: true)
      
    }
    
}
    

