//
//  TableViewCell.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import CoreData

class TableViewCell: UITableViewCell {
    
    @IBOutlet var imgProfile: UIImageView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblRelationship: UILabel!
    
    var idA: Int?
    var imgData: Data?
    
    var chatModel: ChattModel?{
        didSet{
            lblName.text = chatModel?.nombre
            lblRelationship.text = chatModel?.relacion
            idA = chatModel?.id
            imgData = chatModel?.imgData
            if let image = UIImage(data:imgData!) {
                imgProfile.image = image
            }
        }
    }
    
    func getContext() -> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as!
        AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    func consultar(){
        _ = getContext()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Familiar")
        do{
            let results = try getContext().fetch(fetchRequest)
            if results.count > 0 {
                for result in results as! [NSManagedObject]{
                    print(result.value(forKey: "nombre")!)
                    print(result.value(forKey: "apellido")!)
                    print(result.value(forKey: "edad")!)
                    print(result.value(forKey: "direccion")!)
                    print(result.value(forKey: "relacion")!)
                    print(result.value(forKey: "foto")!)
                    print(result.value(forKey: "id")!)
                }
            }
            
        }
        catch{
            print("Error en consulta")
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
