//
//  LoginViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 5/2/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import GoogleSignIn
import Firebase

class LoginViewController: UIViewController, GIDSignInUIDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance().uiDelegate = self
        //GIDSignIn.sharedInstance().signIn()
        
        let gSigIn = GIDSignInButton(frame: CGRect(x: 0, y: 0, width: 230, height: 48 ))
        gSigIn.center = view.center
        view.addSubview(gSigIn)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
