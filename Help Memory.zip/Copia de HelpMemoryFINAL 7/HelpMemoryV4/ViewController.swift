//
//  ViewController.swift
//  HelpMemoryV4
//
//  Created by MaryCarmen Ceron de Mila on 4/30/19.
//  Copyright © 2019 MGAM. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn


class ViewController: UIViewController, GIDSignInUIDelegate {

    var transparentView = UIView()
    var tableView = UITableView()
    
    @IBOutlet weak var user: UILabel!
    let height:CGFloat = 400

    
    var settingArray = ["AGREGAR FAMILIAR","ESTUDIO","INFORMACIÓN","FAMILIARES","GRÁFICA","EQUIPO","CERRAR SESION"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //GIDSignIn.sharedInstance().uiDelegate = self
        // Do any additional setup after loading the view.
        user.text = Auth.auth().currentUser!.email
        tableView.isScrollEnabled = true
        tableView.delegate = self as! UITableViewDelegate
        tableView.dataSource = self as! UITableViewDataSource
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    

    
    @IBAction func OnClickMenu(_ sender: Any) {
        
        let window = UIApplication.shared.keyWindow
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        transparentView.frame = self.view.frame
        window?.addSubview(transparentView)
        
        let screenSize = UIScreen.main.bounds.size
        tableView.frame = CGRect(x: 0, y: screenSize.height, width: screenSize.width, height: height)
        window?.addSubview(tableView)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onClickTransparentView))
        transparentView.addGestureRecognizer(tapGesture)
        
        transparentView.alpha = 0
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations:{self.transparentView.alpha=0.5
            self.tableView.frame = CGRect(x: 0, y: screenSize.height - self.height, width: screenSize.width, height: self.height)
        }, completion: nil)
        
    }
    
    @objc func onClickTransparentView() {
        
        let screenSize = UIScreen.main.bounds.size
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations:{self.transparentView.alpha=0
            self.tableView.frame = CGRect(x: 0, y: screenSize.height, width: screenSize.width, height: self.height)
        }, completion: nil)
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? CustomTableViewCell else {fatalError("Unable to deque cell")}
        cell.lbl.text = settingArray[indexPath.row]
        cell.settingImage.image = UIImage(named: settingArray[indexPath.row])!
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        onClickTransparentView()
        switch indexPath.row {
        case 0:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "FamiliarViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "JugarViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "EstadisticasViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "ConfiguracionViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 4:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "GraficasViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 5:
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "EquipoViewController") else {fatalError("Unable to create viewController")}
            self.navigationController?.pushViewController(vc, animated: true)
        case 6:
            GIDSignIn.sharedInstance()?.signOut()
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
                
                
            } catch let signOutError as NSError {
                print ("Error signing out: %@", signOutError)
            }
            
            let mainStoryboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homePage = mainStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(homePage, animated: true)
        default:
            print("Unable to create viewController")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
